# Feedback Board + AI วิเคราะห์ความคิดเห็นลูกค้า

## โครงสร้างไฟล์

```
feedback-board/
├── index.html                      ← หน้าเว็บทั้งหมด (ฟอร์ม, บอร์ด, ปุ่ม AI)
├── netlify.toml                    ← บอก Netlify ว่าไฟล์อยู่ตรงไหน
├── supabase.sql                    ← คำสั่งสร้างตารางใน Supabase
└── netlify/
    └── functions/
        ├── config.mjs              ← ส่งค่า Supabase ให้หน้าเว็บ  (/api/config)
        └── summarize.mjs           ← เรียก Gemini สรุปรีวิว      (/api/summarize)
```

การทำงาน: หน้าเว็บคุยกับ Supabase โดยตรงเพื่อเขียน/อ่านความคิดเห็น ส่วนปุ่ม AI จะเรียก Netlify Function ซึ่งถือ Gemini API key ไว้ฝั่งเซิร์ฟเวอร์ คีย์จึงไม่หลุดไปอยู่ในเบราว์เซอร์

---

## ขั้นที่ 1 — สร้างฐานข้อมูลใน Supabase

1. ไปที่ https://supabase.com → **Start your project** → ล็อกอิน (ใช้ GitHub ได้)
2. กด **New project** ตั้งชื่อ, ตั้ง Database Password (จดไว้), Region เลือก **Southeast Asia (Singapore)** → **Create new project** รอ 1–2 นาที
3. เมนูซ้าย **SQL Editor** → **New query**
4. เปิดไฟล์ `supabase.sql` คัดลอกทั้งหมดไปวาง → กด **Run** ต้องขึ้น `Success. No rows returned`
5. ตรวจสอบ: เมนู **Table Editor** จะเห็นตาราง `feedback`
6. เก็บค่า 2 อย่างไว้ใช้ขั้นที่ 4 (เมนู **Project Settings** → **API** / **API Keys**; ปุ่ม **Connect** ด้านบนก็มีให้คัดลอก)
   - **Project URL** เช่น `https://abcdxyz.supabase.co`
   - **anon public key** (ขึ้นต้นด้วย `eyJ...`) หรือ **publishable key** (ขึ้นต้นด้วย `sb_publishable_...`) ใช้ตัวไหนก็ได้

> ห้ามใช้ `service_role` หรือ `secret` key เด็ดขาด คีย์นั้นข้าม RLS ได้ทั้งหมด

## ขั้นที่ 2 — ขอ Gemini API key

1. ไปที่ https://aistudio.google.com → ล็อกอินด้วยบัญชี Google
2. กด **Get API key** → **Create API key** → เลือกหรือสร้าง Google Cloud project
3. คัดลอกคีย์ (ขึ้นต้นด้วย `AIza...`) เก็บไว้ อย่าโพสต์หรือใส่ในไฟล์ HTML

## ขั้นที่ 3 — เอาโค้ดขึ้น GitHub

Netlify Functions ต้อง deploy ผ่าน Git หรือ Netlify CLI (การลากไฟล์วางแบบ Netlify Drop จะไม่รัน functions)

1. ไปที่ https://github.com → **New repository** ตั้งชื่อ เช่น `feedback-board` → **Create repository**
2. กดลิงก์ **uploading an existing file** → ลากไฟล์และโฟลเดอร์ทั้งหมดในโฟลเดอร์ `feedback-board` ลงไป (ต้องมีโฟลเดอร์ `netlify/functions` ติดไปด้วย)
3. กด **Commit changes**
4. ตรวจว่าใน repo เห็น `index.html`, `netlify.toml` อยู่ชั้นนอกสุด และมี `netlify/functions/summarize.mjs`

## ขั้นที่ 4 — Deploy บน Netlify + ตั้งค่า API key

1. ไปที่ https://app.netlify.com → ล็อกอินด้วย GitHub
2. **Add new project** (หรือ Add new site) → **Import an existing project** → **GitHub** → เลือก repo `feedback-board`
3. หน้า build settings ปล่อยว่างได้ทั้งหมด (netlify.toml จัดการให้) → กด **Deploy**
4. ไปที่ **Project configuration / Site configuration → Environment variables → Add a variable → Add a single variable** แล้วเพิ่มทีละตัว:

   | Key | Value |
   |---|---|
   | `SUPABASE_URL` | Project URL จากขั้นที่ 1 |
   | `SUPABASE_ANON_KEY` | anon หรือ publishable key จากขั้นที่ 1 |
   | `GEMINI_API_KEY` | คีย์จากขั้นที่ 2 |
   | `GEMINI_MODEL` | (ไม่บังคับ) ค่าเริ่มต้นคือ `gemini-2.5-flash` |

   ตรง Scopes ให้เลือก **All scopes** หรืออย่างน้อยต้องติ๊ก **Functions**
   ตัว `GEMINI_API_KEY` ติ๊ก **Contains secret values** ได้เลย
5. สำคัญ: ตัวแปรใหม่จะมีผลหลัง deploy ใหม่ → ไปที่ **Deploys → Trigger deploy → Deploy project/site**
6. เปิดลิงก์เว็บ (เช่น `https://ชื่อเว็บ.netlify.app`) ลองส่งความคิดเห็น แล้วกด "ให้ AI สรุปรีวิว"

## ขั้นที่ 5 — ปรับแต่ง (ถ้าต้องการ)

- ชื่อร้าน: แก้ `SHOP_NAME` บรรทัดต้น ๆ ของ `<script>` ใน `index.html`
- สีธีม: แก้ตัวแปรใน `:root` ส่วนบนของ `<style>`
- เปลี่ยนโมเดล Gemini: แก้ `GEMINI_MODEL` ใน Netlify แล้ว redeploy (ดูชื่อรุ่นที่ใช้ได้ที่ https://ai.google.dev/gemini-api/docs/models)
- แก้ไฟล์บน GitHub เมื่อไร Netlify จะ deploy ใหม่ให้อัตโนมัติ

---

## แก้ปัญหาที่พบบ่อย

| อาการ | สาเหตุ / วิธีแก้ |
|---|---|
| แถบแดง "เชื่อมต่อฐานข้อมูลไม่ได้" | ยังไม่ตั้ง `SUPABASE_URL`/`SUPABASE_ANON_KEY` หรือยังไม่ได้ Trigger deploy ใหม่ หรือเปิดไฟล์ index.html จากเครื่องตรง ๆ (ต้องเปิดผ่านลิงก์ Netlify) |
| เปิด `/api/config` แล้วได้ 404 | โฟลเดอร์ `netlify/functions` ไม่ได้ถูกอัปโหลดขึ้น GitHub หรือ `netlify.toml` ไม่ได้อยู่ชั้นนอกสุด |
| ส่งแล้วขึ้น `new row violates row-level security policy` | ยังไม่ได้รัน `supabase.sql` ครบ ให้รันใหม่อีกรอบ |
| คะแนนเฉลี่ยขึ้น "–" ตลอด | ฟังก์ชัน `feedback_stats` ยังไม่ถูกสร้าง ให้รัน `supabase.sql` อีกครั้ง |
| AI: `API key not valid` | คีย์ Gemini ผิด หรือมีช่องว่างติดมา ตั้งใหม่แล้ว redeploy |
| AI: model not found | ชื่อรุ่นใน `GEMINI_MODEL` ไม่มีแล้ว เปลี่ยนเป็นรุ่นที่ยังเปิดให้ใช้ |
| AI: timeout / 502 หลังรอประมาณ 10 วินาที | Netlify function มีเวลาจำกัด ลองกดใหม่ หรือใช้รุ่นที่เร็วกว่า เช่น `gemini-2.5-flash-lite` |
| การ์ดใหม่ไม่เด้งเอง | Realtime ยังไม่เปิด (ส่วนที่ 4 ใน supabase.sql) แต่รีเฟรชหน้าแล้วจะเห็นปกติ |
| ดู log ของ function | Netlify → **Logs → Functions** → เลือก `summarize` |

## เรื่องความปลอดภัย

- Gemini key อยู่ใน Netlify Environment variables เท่านั้น ไม่มีในไฟล์ที่ส่งไปเบราว์เซอร์
- Supabase anon/publishable key เปิดเผยได้ตามการออกแบบ สิ่งที่ปกป้องข้อมูลคือ RLS: คนทั่วไปอ่านและเพิ่มได้ แต่แก้ไข/ลบไม่ได้
- ถ้าเจอสแปม ลบรายการได้จาก Supabase → Table Editor และอาจเพิ่มระบบกันบอต (เช่น Cloudflare Turnstile) ภายหลัง
- ฟังก์ชันสรุปดึงรีวิวจากฐานข้อมูลเอง และสั่ง AI ให้ถือว่าข้อความรีวิวเป็นข้อมูล ไม่ใช่คำสั่ง
